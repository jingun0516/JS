console.log("이름\t나이");
console.log("안녕\n하세요");
console.log("\\\\");