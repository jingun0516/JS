console.log(52 < 273);
console.log(52 > 273);
console.log("하마" < "가방");